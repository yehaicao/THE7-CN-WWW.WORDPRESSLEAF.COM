<?php
// load child theme textdomain
/*
function presscore_load_text_domain() {
	load_child_theme_textdomain( 'presscore', get_stylesheet_directory() . '/languages' );
}
*/

/**
 * Your code here.
 *
 */